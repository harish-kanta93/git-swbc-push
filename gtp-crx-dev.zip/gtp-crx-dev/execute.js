/*!********************************!*\
  !*** ./src/execute/execute.js ***!
  \********************************/
const actionScripts = {
   alertDisabler: async function ({value}) {
      window.alert = function alert(msg) {};
      window.confirm = function confirm(msg) {
         return value;
      };
      window.prompt = function prompt(msg) {
         if (value == undefined || value == "undefined") {
            return undefined;
         } else {
            return value;
         }
      };
   },
   alertDisablerScript: async function (alertValue) {
      try {
         let disablerCode = "";
         let param = {
            value: typeof alertValue == "string" ? "'" + alertValue + "'" : alertValue,
         };
         actionScripts["alertDisabler"](param);

         let disablerScriptElement = document.createElement("script");
         disablerScriptElement.textContent = disablerCode;
         document.documentElement.appendChild(disablerScriptElement);

         disablerScriptElement.parentNode.removeChild(disablerScriptElement);
         return {actionCompleted: true, actionMessage: "success"};
      } catch (e) {
         return {actionCompleted: true, actionMessage: e.message};
      }
   },
   initializeAlertValue: async function ({value}) {
      alertDisabler(value);
   },
   EnableSpinner: async function () {
      window.onbeforeunload = function () {
         document.body.style.cursor = "wait";
      };

      window.onload = function () {
         document.body.style.cursor = "default";
      };
   },
   SendMessageToApp: async function ({value}) {
      console.log(`Sending ${value} to GTP webapp`);
      window.postMessage(
         {
            type: value,
            text: `Sending ${value} to GTP webapp`,
         },
         "*"
      );
   },
};

console.log("execute.js loaded");


//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhlY3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7QUFBQTtBQUNBLG1DQUFtQyxNQUFNO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixRQUFRO0FBQ1IsaUJBQWlCO0FBQ2pCO0FBQ0EsSUFBSTtBQUNKLDBDQUEwQyxNQUFNO0FBQ2hEO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osc0NBQXNDLE1BQU07QUFDNUMsNkJBQTZCLE9BQU87QUFDcEM7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLE9BQU87QUFDcEMsVUFBVTtBQUNWO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3RwX3YzLy4vc3JjL2V4ZWN1dGUvZXhlY3V0ZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBhY3Rpb25TY3JpcHRzID0ge1xyXG4gICBhbGVydERpc2FibGVyOiBhc3luYyBmdW5jdGlvbiAoe3ZhbHVlfSkge1xyXG4gICAgICB3aW5kb3cuYWxlcnQgPSBmdW5jdGlvbiBhbGVydChtc2cpIHt9O1xyXG4gICAgICB3aW5kb3cuY29uZmlybSA9IGZ1bmN0aW9uIGNvbmZpcm0obXNnKSB7XHJcbiAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgICAgfTtcclxuICAgICAgd2luZG93LnByb21wdCA9IGZ1bmN0aW9uIHByb21wdChtc2cpIHtcclxuICAgICAgICAgaWYgKHZhbHVlID09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICB9LFxyXG4gICBhbGVydERpc2FibGVyU2NyaXB0OiBhc3luYyBmdW5jdGlvbiAoYWxlcnRWYWx1ZSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgICBsZXQgZGlzYWJsZXJDb2RlID0gXCJcIjtcclxuICAgICAgICAgbGV0IHBhcmFtID0ge1xyXG4gICAgICAgICAgICB2YWx1ZTogdHlwZW9mIGFsZXJ0VmFsdWUgPT0gXCJzdHJpbmdcIiA/IFwiJ1wiICsgYWxlcnRWYWx1ZSArIFwiJ1wiIDogYWxlcnRWYWx1ZSxcclxuICAgICAgICAgfTtcclxuICAgICAgICAgYWN0aW9uU2NyaXB0c1tcImFsZXJ0RGlzYWJsZXJcIl0ocGFyYW0pO1xyXG5cclxuICAgICAgICAgbGV0IGRpc2FibGVyU2NyaXB0RWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIik7XHJcbiAgICAgICAgIGRpc2FibGVyU2NyaXB0RWxlbWVudC50ZXh0Q29udGVudCA9IGRpc2FibGVyQ29kZTtcclxuICAgICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGRpc2FibGVyU2NyaXB0RWxlbWVudCk7XHJcblxyXG4gICAgICAgICBkaXNhYmxlclNjcmlwdEVsZW1lbnQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChkaXNhYmxlclNjcmlwdEVsZW1lbnQpO1xyXG4gICAgICAgICByZXR1cm4ge2FjdGlvbkNvbXBsZXRlZDogdHJ1ZSwgYWN0aW9uTWVzc2FnZTogXCJzdWNjZXNzXCJ9O1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgIHJldHVybiB7YWN0aW9uQ29tcGxldGVkOiB0cnVlLCBhY3Rpb25NZXNzYWdlOiBlLm1lc3NhZ2V9O1xyXG4gICAgICB9XHJcbiAgIH0sXHJcbiAgIGluaXRpYWxpemVBbGVydFZhbHVlOiBhc3luYyBmdW5jdGlvbiAoe3ZhbHVlfSkge1xyXG4gICAgICBhbGVydERpc2FibGVyKHZhbHVlKTtcclxuICAgfSxcclxuICAgRW5hYmxlU3Bpbm5lcjogYXN5bmMgZnVuY3Rpb24gKCkge1xyXG4gICAgICB3aW5kb3cub25iZWZvcmV1bmxvYWQgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuY3Vyc29yID0gXCJ3YWl0XCI7XHJcbiAgICAgIH07XHJcblxyXG4gICAgICB3aW5kb3cub25sb2FkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLmN1cnNvciA9IFwiZGVmYXVsdFwiO1xyXG4gICAgICB9O1xyXG4gICB9LFxyXG4gICBTZW5kTWVzc2FnZVRvQXBwOiBhc3luYyBmdW5jdGlvbiAoe3ZhbHVlfSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhgU2VuZGluZyAke3ZhbHVlfSB0byBHVFAgd2ViYXBwYCk7XHJcbiAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZShcclxuICAgICAgICAge1xyXG4gICAgICAgICAgICB0eXBlOiB2YWx1ZSxcclxuICAgICAgICAgICAgdGV4dDogYFNlbmRpbmcgJHt2YWx1ZX0gdG8gR1RQIHdlYmFwcGAsXHJcbiAgICAgICAgIH0sXHJcbiAgICAgICAgIFwiKlwiXHJcbiAgICAgICk7XHJcbiAgIH0sXHJcbn07XHJcblxyXG5jb25zb2xlLmxvZyhcImV4ZWN1dGUuanMgbG9hZGVkXCIpO1xyXG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=