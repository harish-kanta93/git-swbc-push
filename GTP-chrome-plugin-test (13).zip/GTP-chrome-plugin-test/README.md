# GoTestPro Chrome Extension

## Overview

GoTestPro is an advanced Test Automation Tool designed specifically for Software Developers and QA Engineers. It streamlines the process of creating and executing automated test scenarios for web applications through an intuitive Chrome extension recorder.

## Key Features

### Test Recording

-  Record test scenarios in real-time on any web application
-  Works in lower environments and production
-  Automatic test script generation
-  No coding required for basic test creation

### Element Selection

-  Advanced XPath extraction capabilities
-  CSS selector identification
-  Interactive element picker
-  Smart element recognition

### Test Execution

-  Playback recorded test scenarios directly through the extension
-  Cloud-based test execution support
-  JavaScript-based test scenario execution
-  Cross-browser compatibility

### Test Management

-  Save recorded tests to GoTestPro Web Application
-  Organize tests into regression suites
-  Maintain test scenario versions
-  Share tests across team members

## Use Cases

1. **Regression Testing**

   -  Create automated test suites
   -  Maintain test scenarios
   -  Regular execution of test cases

2. **Cross-browser Testing**

   -  Test web applications across different browsers
   -  Ensure consistent behavior
   -  Validate UI components

3. **CI/CD Integration**
   -  Integrate with continuous integration pipelines
   -  Automated test execution
   -  Regular validation of application changes

## Getting Started

1. Install the extension from the [Chrome Web Store](https://chromewebstore.google.com/detail/ldmfmccaoihffboppndecjpfldhamafn)
2. Log in to your GoTestPro account
3. Start recording your first test scenario
4. Save and execute tests as needed

## Technical Features

-  JavaScript-based test automation
-  XPath and CSS selector support
-  Cloud execution capabilities
-  Browser-based recording
-  Seamless integration with web applications

## Target Users

-  Software Developers
-  QA Engineers
-  Test Automation Engineers
-  Quality Assurance Teams
-  Development Teams

## Benefits

-  Reduce manual testing effort
-  Increase test coverage
-  Improve testing efficiency
-  No coding required for basic tests
-  Quick test creation and execution
-  Cloud-based test management

## Support

For more information and support:

-  Visit [GoTestPro Website](https://app.gotestpro.com/)
-  Contact technical support through the web application
-  Access documentation and tutorials

## System Requirements

-  Google Chrome browser
-  Internet connection
-  Access to test environment
-  GoTestPro account

## Installation

1. Download the GTP-PW folder from the repo
2. Go to Chrome
3. Settings using the three dots in the top right corner
4. Select Extensions
5. Click Load Unpacked
6. Select the GTP-PW

Start automating your web application testing today with GoTestPro!
